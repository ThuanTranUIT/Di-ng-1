package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.service.autofill.OnClickAction;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

    public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //  Khai báo cho các nút.

    private EditText edt_number_input;
    private EditText edt_result;
    //  Button
    private Button btnNumber1;
    private Button btnNumber2;
    private Button btnNumber3;
    private Button btnNumber4;
    private Button btnNumber5;
    private Button btnNumber6;
    private Button btnNumber7;
    private Button btnNumber8;
    private Button btnNumber9;
    private Button btnNumber0;
    private Button btnNhan;
    private Button btnChia;
    private Button btnCong;
    private Button btnTru;
    private Button btnBang;
    private Button btnCham;
    private Button btnCongTru;
    private Button btnPhantram;
    private Button btnCE;
    private Button btnC;
    private Button btnDelete;
    private Button btn1chiax;
    private Button btnXbinh;
    private Button btn2canx;
    Boolean cong = false, tru = false, nhan = false, chia = false;
    Double var1;
    Double var2;
    Double ans;
    String result_after ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initWidget();
        setEvenClickViews();
    }
    public void  initWidget()
    {
        // 2 edt không cần xét sự kiện Onlick.
        edt_number_input = (EditText) findViewById(R.id.edt_number_input);
        edt_result = (EditText) findViewById(R.id.edt_result);

        // Button khởi tạo ở trên chính là button ở trong xml file sau khi đặt id
        btnNumber1 = (Button) findViewById(R.id.btnNumber1);
        btnNumber2 = (Button) findViewById(R.id.btnNumber2);
        btnNumber3 = (Button) findViewById(R.id.btnNumber3);
        btnNumber4 = (Button) findViewById(R.id.btnNumber4);
        btnNumber5 = (Button) findViewById(R.id.btnNumber5);
        btnNumber6 = (Button) findViewById(R.id.btnNumber6);
        btnNumber7 = (Button) findViewById(R.id.btnNumber7);
        btnNumber8 = (Button) findViewById(R.id.btnNumber8);
        btnNumber9 = (Button) findViewById(R.id.btnNumber9);
        btnNumber0 = (Button) findViewById(R.id.btnNumber0);
        btnNhan = (Button) findViewById(R.id.btnNhan);
        btnChia = (Button) findViewById(R.id.btnChia);
        btnCong = (Button) findViewById(R.id.btnCong);
        btnTru = (Button) findViewById(R.id.btnTru);
        btnBang = (Button) findViewById(R.id.btnBang);
        btnCham = (Button) findViewById(R.id.btnCham);
        btnCongTru = (Button) findViewById(R.id.btnCongTru);
        btnPhantram = (Button) findViewById(R.id.btnPhantram);
        btnCE = (Button) findViewById(R.id.btnCE);
        btnC = (Button) findViewById(R.id.btnC);
        btnDelete = (Button) findViewById(R.id.btnDelete);
        btn1chiax = (Button) findViewById(R.id.btn1chiax);
        btnXbinh = (Button) findViewById(R.id.btnXbinh);
        btn2canx = (Button) findViewById(R.id.btn2canx);


    }
    // Khai báo việc lắng nghe sự kiện : Lắng nghe sự kiện
    public void setEvenClickViews()
    {
        // Khai báo bắt sự kiện khi duoc click ở button.
        btnNumber1.setOnClickListener(this);
        btnNumber2.setOnClickListener(this);
        btnNumber3.setOnClickListener(this);
        btnNumber4.setOnClickListener(this);
        btnNumber5.setOnClickListener(this);
        btnNumber6.setOnClickListener(this);
        btnNumber7.setOnClickListener(this);
        btnNumber8.setOnClickListener(this);
        btnNumber9.setOnClickListener(this);
        btnNumber0.setOnClickListener(this);
        btnNhan.setOnClickListener(this);
        btnChia.setOnClickListener(this);
        btnCong.setOnClickListener(this);
        btnTru.setOnClickListener(this);
        btnBang.setOnClickListener(this);
        btnCham.setOnClickListener(this);
        btnCongTru.setOnClickListener(this);
        btnPhantram.setOnClickListener(this);
        btnCE.setOnClickListener(this);
        btnC.setOnClickListener(this);
        btnDelete.setOnClickListener(this);
        btn1chiax.setOnClickListener(this);
        btnXbinh.setOnClickListener(this);
        btn2canx.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        // Khi hàm setEvenClickViews lắng nghe sự kiện có hành động click thì vào vào hàm này
        switch (v.getId())
        {

            case R.id.btnNumber1:
                edt_result.append("1");

            break;
            case R.id.btnNumber2:
                edt_result.append("2");
            break;
            case R.id.btnNumber3:
                edt_result.append("3");
            break;
            case R.id.btnNumber4:
                edt_result.append("4");
            break;
            case R.id.btnNumber5:
                edt_result.append("5");
            break;
            case R.id.btnNumber6:
                edt_result.append("6");
            break;
            case R.id.btnNumber7:
                edt_result.append("7");
            break;
            case R.id.btnNumber8:
                edt_result.append("8");
            break;
            case R.id.btnNumber9:
                edt_result.append("9");
            break;
            case R.id.btnNumber0:
                edt_result.append("0");
            break;
            case R.id.btnNhan:
            {
                String result = edt_result.getText().toString();
                edt_number_input.setText(result + "*");
                nhan = true;
                edt_result.setText("");
            }
            break;
            case R.id.btnChia:
            {
                String result = edt_result.getText().toString();
                edt_number_input.setText(result + ":");
                chia = true;
                edt_result.setText("");
            }
            break;
            case R.id.btnCong:
            {
                String result = edt_result.getText().toString();
                edt_number_input.setText(result + "+");
                cong = true;
                edt_result.setText("");
            }
            break;
            case R.id.btnTru:
            {
                String result = edt_result.getText().toString();
                edt_number_input.setText(result + "-");
                tru = true;
                edt_result.setText("");
            }
            break;
            case R.id.btnBang:
                var2 = Double.parseDouble(edt_result.getText().toString());
                var1 = Double.parseDouble(deleteNumber(edt_number_input.getText().toString()));
                if(cong){
                    ans = var1 + var2;
                } else if (tru){
                    ans = var1 - var2;
                } else if (nhan){
                    ans = var1 * var2;
                } else {
                    ans = var1 / var2;
                }
                edt_number_input.setText(edt_number_input.getText().toString() + edt_result.getText().toString() + "=");
                edt_result.setText(ans.toString());

            break;
            case R.id.btnCham:
                edt_result.append(".");
            break;
            case R.id.btnCongTru:
            break;
            case R.id.btnPhantram:
            break;
            case R.id.btnCE:
                edt_result.setText("");
            break;
            case R.id.btnC:
                edt_result.setText("");
                edt_number_input.setText("");
            break;
            case R.id.btnDelete:
                String newresult = deleteNumber(edt_result.getText().toString());
                edt_result.setText(newresult);
            break;
            case R.id.btn1chiax:
            break;
            case R.id.btnXbinh:
            break;
            case R.id.btn2canx:
            break;


        }
    }
    public  String deleteNumber( String number)
    {
        int len = number.length();
        String temp = number.substring(0, len - 1);
        return  temp;
    }

}